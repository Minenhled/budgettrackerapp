package vcmsa.projects.budgettrackerapp.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import vcmsa.projects.budgettrackerapp.data.model.Entry

@Dao
interface EntryDao {

    @Insert
    suspend fun insert(entry: Entry): Long

    @Query("SELECT * FROM Entry WHERE userId = :userId")
    suspend fun getEntriesByUser(userId: Int): List<Entry>
}

//Reference List//


