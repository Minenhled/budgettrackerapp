package vcmsa.projects.budgettrackerapp.ui.theme

import android.annotation.SuppressLint
import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.*
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.CreateCategoryScreen
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.CreateEntryScreen
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.HomeScreen
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.LoginScreen
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.RegisterScreen
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.ViewEntriesScreen
import vcmsa.projects.budgettrackerapp.viewmodel.AuthViewModel
import vcmsa.projects.budgettrackerapp.viewmodel.CategoryViewModel
import vcmsa.projects.budgettrackerapp.viewmodel.EntryViewModel

@SuppressLint("ViewModelConstructorInComposable")
@Composable
private fun BudgetTrackerApp(authViewModel: AuthViewModel) {
    // Initialize the navController for navigation
    val navController = rememberNavController()

    // Get Application context for the ViewModels
    val context = LocalContext.current.applicationContext as Application

    // ViewModels for different screens
    val entryViewModel = EntryViewModel(application = context)  // Using EntryViewModel directly
    val categoryViewModel = CategoryViewModel(context)

    // Define the NavHost with the start destination
    NavHost(navController = navController, startDestination = "login") {
        // Login Screen
        composable("login") {
            LoginScreen(
                authViewModel,
                onLoginSuccess = { navController.navigate("home") },
                onNavigateToRegister = { navController.navigate("register") }
            )
        }

        // Register Screen
        composable("register") {
            RegisterScreen(authViewModel) {
                navController.popBackStack()
            }
        }

        // Home Screen
        composable("home") {
            HomeScreen { navController.navigate("create_entry/${authViewModel.currentUserId.value}") }
        }

        // Create Category Screen
        composable("create_category/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId")?.toInt() ?: 0
            CreateCategoryScreen(userId, categoryViewModel) {
                navController.popBackStack()
            }
        }

        // Create Entry Screen
        composable("create_entry/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId")?.toInt() ?: 0
            CreateEntryScreen(userId, 1, entryViewModel) { // Category ID = 1 (can be dynamic later)
                navController.popBackStack()
            }
        }

        // View Entries Screen
        composable("view_entries/{userId}") { backStackEntry ->
            val userId = backStackEntry.arguments?.getString("userId")?.toInt() ?: 0
            ViewEntriesScreen(userId, entryViewModel)
        }
    }
}
// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st

