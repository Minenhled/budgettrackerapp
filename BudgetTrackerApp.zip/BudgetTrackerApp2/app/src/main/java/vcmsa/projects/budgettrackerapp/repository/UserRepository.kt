package vcmsa.projects.budgettrackerapp.repository



import vcmsa.projects.budgettrackerapp.data.dao.UserDao
import vcmsa.projects.budgettrackerapp.data.model.User

class UserRepository(private val userDao: UserDao) {
    suspend fun login(username: String, password: String) = userDao.login(username, password)
    suspend fun register(user: User) = userDao.insert(user)
}
