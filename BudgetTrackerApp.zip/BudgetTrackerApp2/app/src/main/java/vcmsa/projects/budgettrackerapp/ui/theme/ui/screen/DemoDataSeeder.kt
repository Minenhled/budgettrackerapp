package vcmsa.projects.budgettrackerapp.ui.theme.ui.screen



import android.content.Context
import vcmsa.projects.budgettrackerapp.data.db.AppDatabase
import vcmsa.projects.budgettrackerapp.data.model.Category
import vcmsa.projects.budgettrackerapp.data.model.Entry
import vcmsa.projects.budgettrackerapp.data.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object DemoDataSeeder {

    fun seed(context: Context) {
        val db = AppDatabase.getInstance(context)
        CoroutineScope(Dispatchers.IO).launch {
            val user = User(username = "demo", password = "password")
            val userId = db.userDao().insert(user).toInt()

            val category = Category(name = "Food", userId = userId)
            val categoryId = db.categoryDao().insert(category).toInt()

            val entry = Entry(
                userId = userId,
                categoryId = categoryId,
                date = "2025-05-01",
                startTime = "12:00",
                endTime = "13:00",
                description = "Lunch at cafe",
                amount = 15.0,
                photoPath = null
            )
            db.entryDao().insert(entry)
        }
    }
}
