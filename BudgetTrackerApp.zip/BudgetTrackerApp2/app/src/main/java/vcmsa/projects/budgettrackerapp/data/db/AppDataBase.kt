package vcmsa.projects.budgettrackerapp.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import vcmsa.projects.budgettrackerapp.data.dao.* // Import all your DAOs
import vcmsa.projects.budgettrackerapp.data.model.* // Import all your models (User, Category, Entry, Goal)

@Database(
    entities = [User::class, Category::class, Entry::class, Goal::class], // Define entities
    version = 1, // Define version of your database
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // Abstract functions for each DAO (Data Access Object)
    abstract fun userDao(): UserDao
    abstract fun categoryDao(): CategoryDao
    abstract fun entryDao(): EntryDao
    abstract fun goalDao(): GoalDao

    // Singleton pattern for the database instance
    companion object {
        const val DATABASE_NAME = "budgettrackerapp.db" // Constant for DB name

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME // Use the constant for the database name
                )
                    .fallbackToDestructiveMigration() // Allows destructive migration if schema version changes
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}




// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st
