package vcmsa.projects.budgettrackerapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import vcmsa.projects.budgettrackerapp.data.db.AppDatabase
import vcmsa.projects.budgettrackerapp.data.model.Goal
import kotlinx.coroutines.launch

class GoalViewModel(application: Application) : AndroidViewModel(application) {

    private val goalDao = AppDatabase.getInstance(application).goalDao()

    // Insert a goal into the database
    fun setGoal(goal: Goal) {
        viewModelScope.launch {
            goalDao.insert(goal)
        }
    }

    // Fetch the goal by userId using the DAO's function
    fun getGoal(userId: Int, onResult: (Goal?) -> Unit) {
        viewModelScope.launch {
            val goal = goalDao.getGoalByUser(userId)
            onResult(goal)  // Return the goal using the callback
        }
    }
}

