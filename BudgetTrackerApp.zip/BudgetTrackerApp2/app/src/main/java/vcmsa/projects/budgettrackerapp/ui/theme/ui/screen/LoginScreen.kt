package vcmsa.projects.budgettrackerapp.ui.theme.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import vcmsa.projects.budgettrackerapp.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    authViewModel: AuthViewModel,
    onLoginSuccess: () -> Unit,
    onNavigateToRegister: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                authViewModel.login(username, password) { success ->
                    if (success) {
                        onLoginSuccess()
                    } else {
                        // Show login error, maybe show a Toast
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }

        Spacer(modifier = Modifier.height(8.dp))

        TextButton(
            onClick = onNavigateToRegister,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Don't have an account? Register")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    // A mock ViewModel can be passed here in case you want to test the UI.
    LoginScreen(
        authViewModel = AuthViewModel(),
        onLoginSuccess = {},
        onNavigateToRegister = {}
    )
}

fun AuthViewModel(): AuthViewModel {

    return TODO("Provide the return value")
}
//Reference List//
// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st

