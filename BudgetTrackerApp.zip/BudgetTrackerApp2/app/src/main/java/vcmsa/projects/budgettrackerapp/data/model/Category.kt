import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "Category")
data class Category(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val name: String,
    val description: String
) : Parcelable {

    constructor(parcel: Parcel) : this(
        id = parcel.readInt(),
        userId = parcel.readInt(),
        name = parcel.readString() ?: "",
        description = parcel.readString() ?: ""
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeInt(userId)
        parcel.writeString(name)
        parcel.writeString(description)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Category> {
        override fun createFromParcel(parcel: Parcel): Category {
            return Category(parcel)
        }

        override fun newArray(size: Int): Array<Category?> {
            return arrayOfNulls(size)
        }
    }
}


// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st
