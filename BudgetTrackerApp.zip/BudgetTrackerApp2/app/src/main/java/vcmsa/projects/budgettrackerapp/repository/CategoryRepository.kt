 package vcmsa.projects.budgettrackerapp.repository

import Category
import vcmsa.projects.budgettrackerapp.data.dao.CategoryDao
import vcmsa.projects.budgettrackerapp.data.model.Category

class CategoryRepository(private val categoryDao: CategoryDao) {
    suspend fun insert(category: Category) = categoryDao.insert(category)
    suspend fun getAllCategories(userId: Int) = categoryDao.getCategoriesByUser(userId)
}


// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st
