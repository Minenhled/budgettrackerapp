package vcmsa.projects.budgettrackerapp.ui.theme.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import vcmsa.projects.budgettrackerapp.data.model.Entry
import vcmsa.projects.budgettrackerapp.viewmodel.EntryViewModel

@Composable
fun CreateEntryScreen(
    userId: Int,
    categoryId: Int,
    viewModel: EntryViewModel,
    onEntryCreated: () -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = PickVisualMedia()
    ) { uri ->
        photoUri = uri
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Amount") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(PickVisualMedia.ImageOnly)
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Select Photo")
        }

        photoUri?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Image(
                painter = rememberAsyncImagePainter(it),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                val amountValue = amount.toDoubleOrNull() ?: 0.0
                val entry = Entry(
                    userId = userId,
                    categoryId = categoryId,
                    date = "2025-05-02", // Replace with real date picker if needed
                    startTime = "08:00",
                    endTime = "10:00",
                    description = description,
                    amount = amountValue,
                    photoPath = photoUri?.toString()
                )
                viewModel.addEntry(entry)
                onEntryCreated()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save Entry")
        }
    }
}

//Reference List//

//1. Android Developers. (2023). *Room Persistence Library*. \[online] Available at: [https://developer.android.com/training/data-storage/room](https://developer.android.com/training/data-storage/room) \[Accessed 2 May 2025].
//
//2. Android Developers. (2023). *RecyclerView Overview*. \[online] Available at: [https://developer.android.com/guide/topics/ui/layout/recyclerview](https://developer.android.com/guide/topics/ui/layout/recyclerview) \[Accessed 2 May 2025].
//
//3. Android Developers. (2023). *Intents and Intent Filters*. \[online] Available at: [https://developer.android.com/guide/components/intents-filters](https://developer.android.com/guide/components/intents-filters) \[Accessed 2 May 2025].
//
//4. Android Developers. (2023). *ConstraintLayout*. \[online] Available at: [https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout](https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout) \[Accessed 2 May 2025].
//
//5. Kotlin. (2023). *Kotlin Documentation*. \[online] Available at: [https://kotlinlang.org/docs/home.html](https://kotlinlang.org/docs/home.html) \[Accessed 2 May 2025].
//
//6. Android Developers. (2023). *Saving Data with SharedPreferences*. \[online] Available at: [https://developer.android.com/training/data-storage/shared-preferences](https://developer.android.com/training/data-storage/shared-preferences) \[Accessed 2 May 2025].
//
//7. Android Developers. (2023). *ViewModel Overview*. \[online] Available at: [https://developer.android.com/topic/libraries/architecture/viewmodel](https://developer.android.com/topic/libraries/architecture/viewmodel) \[Accessed 2 May 2025].
//
//8. Android Developers. (2023). *Activities*. \[online] Available at: [https://developer.android.com/guide/components/activities](https://developer.android.com/guide/components/activities) \[Accessed 2 May 2025].
//
//9. Android Developers. (2023). *Room Database Migration*. \[online] Available at: [https://developer.android.com/training/data-storage/room/migrating](https://developer.android.com/training/data-storage/room/migrating) \[Accessed 2 May 2025].
//
//10. Google. (2023). *Material Design*. \[online] Available at: [https://material.io/design](https://material.io/design) \[Accessed 2 May 2025].

