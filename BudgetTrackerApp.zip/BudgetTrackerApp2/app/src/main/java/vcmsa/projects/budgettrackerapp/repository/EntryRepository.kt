package vcmsa.projects.budgettrackerapp.repository



import vcmsa.projects.budgettrackerapp.data.dao.EntryDao
import vcmsa.projects.budgettrackerapp.data.model.Entry

class EntryRepository(private val entryDao: EntryDao) {
    suspend fun insert(entry: Entry) = entryDao.insert(entry)
    suspend fun getEntriesByUser(userId: Int) = entryDao.getEntriesByUser(userId)
}
