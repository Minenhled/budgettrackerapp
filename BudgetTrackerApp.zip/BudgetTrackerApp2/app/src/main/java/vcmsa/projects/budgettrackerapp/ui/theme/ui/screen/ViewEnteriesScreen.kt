package vcmsa.projects.budgettrackerapp.ui.theme.ui.screen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import vcmsa.projects.budgettrackerapp.data.model.Entry
import vcmsa.projects.budgettrackerapp.viewmodel.EntryViewModel
import java.io.File

@Composable
fun ViewEntriesScreen(
    userId: Int,
    viewModel: EntryViewModel
) {
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }

    // Load entries on first composition
    LaunchedEffect(userId) {
        entries = viewModel.getEntries(userId)
    }

    LazyColumn(modifier = Modifier.padding(16.dp)) {
        items(entries) { entry ->
            EntryCard(entry)
        }
    }
}

@Composable
fun EntryCard(entry: Entry) {
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Load bitmap asynchronously if photoPath exists
    LaunchedEffect(entry.photoPath) {
        entry.photoPath?.let { path ->
            bitmap = loadImageFromPath(path)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text("Date: ${entry.date}")
            Text("Time: ${entry.startTime} - ${entry.endTime}")
            Text("Amount: \$${entry.amount}")
            Text("Description: ${entry.description}")

            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = "Expense photo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(top = 8.dp)
                )
            }
        }
    }
}

suspend fun loadImageFromPath(photoPath: String): Bitmap? {
    return withContext(Dispatchers.IO) {
        val imgFile = File(photoPath)
        if (imgFile.exists()) {
            BitmapFactory.decodeFile(photoPath)
        } else {
            null
        }
    }
}


// Reference List:
// Android Developers. (2023). Room Persistence Library. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Android Developers. (2023). Layouts. Retrieved from https://developer.android.com/guide/topics/ui/declaring-layout
// Android Developers. (2023). Activities and the Activity Lifecycle. Retrieved from https://developer.android.com/guide/components/activities/activity-lifecycle
// Android Developers. (2023). UI Components: Button, TextView, EditText, etc. Retrieved from https://developer.android.com/reference/android/widget/Button
// Kotlin Documentation. (2023). Kotlin Programming Guide - Singleton Pattern. Retrieved from https://kotlinlang.org/docs/object-declarations.html
// Android Developers. (2023). Data Binding and Room. Retrieved from https://developer.android.com/topic/libraries/architecture/room
// Kotlin Documentation. (2023). Coroutines in Kotlin. Retrieved from https://kotlinlang.org/docs/coroutines-overview.html
// Android Developers. (2023). Permissions Overview. Retrieved from https://developer.android.com/guide/topics/permissions/overview
// Android Developers. (2023). Database Migration with Room. Retrieved from https://developer.android.com/training/data-storage/room/migrating-db
// Google. (2023). Android Studio - Official Integrated Development Environment (IDE) for Android Development. Retrieved from https://developer.android.com/studio
// Kotlin Foundation. (2023). Kotlin Programming Language. Retrieved from https://kotlinlang.org/
// Android Developers. (2023). ConstraintLayout: A flexible layout for Android. Retrieved from https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout
// Android Developers. (2023). Android User Interface (UI) Components. Retrieved from https://developer.android.com/reference/android/widget
// Android Developers. (2023). Room Database Architecture. Retrieved from https://developer.android.com/training/data-st

