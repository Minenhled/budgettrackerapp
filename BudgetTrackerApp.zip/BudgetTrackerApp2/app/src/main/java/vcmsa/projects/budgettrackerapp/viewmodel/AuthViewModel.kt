import android.app.Application
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import vcmsa.projects.budgettrackerapp.data.db.AppDatabase
import vcmsa.projects.budgettrackerapp.data.model.User

private val Any.id: Int?
    get() {
        TODO("Not yet implemented")
    }

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val userDao = AppDatabase.getInstance(application).userDao()

    // State to track the current user
    val currentUserId = mutableStateOf<Int?>(null)

    // Register a new user
    fun register(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val existingUser = userDao.getUserByUsername(username)
                if (existingUser == null) {
                    val newUser = User(username = username, password = password)
                    userDao.insert(newUser)

                    // Retrieve inserted user to get ID
                    val insertedUser = userDao.getUserByUsername(username)
                    currentUserId.value = insertedUser?.id
                    onResult(true)
                } else {
                    onResult(false) // User already exists
                }
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false) // Handle error, notify user if needed
            }
        }
    }

    // Login an existing user
    fun login(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val user = userDao.getUserByUsernameAndPassword(username, password)
                if (user != null) {
                    currentUserId.value = user.id
                    onResult(true)
                } else {
                    onResult(false) // Invalid credentials
                }
            } catch (e: Exception) {
                e.printStackTrace()
                onResult(false) // Handle error, notify user if needed
            }
        }
    }
}
//Reference List//

//1. Android Developers. (2023). *Room Persistence Library*. \[online] Available at: [https://developer.android.com/training/data-storage/room](https://developer.android.com/training/data-storage/room) \[Accessed 2 May 2025].
//
//2. Android Developers. (2023). *RecyclerView Overview*. \[online] Available at: [https://developer.android.com/guide/topics/ui/layout/recyclerview](https://developer.android.com/guide/topics/ui/layout/recyclerview) \[Accessed 2 May 2025].
//
//3. Android Developers. (2023). *Intents and Intent Filters*. \[online] Available at: [https://developer.android.com/guide/components/intents-filters](https://developer.android.com/guide/components/intents-filters) \[Accessed 2 May 2025].
//
//4. Android Developers. (2023). *ConstraintLayout*. \[online] Available at: [https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout](https://developer.android.com/reference/androidx/constraintlayout/widget/ConstraintLayout) \[Accessed 2 May 2025].
//
//5. Kotlin. (2023). *Kotlin Documentation*. \[online] Available at: [https://kotlinlang.org/docs/home.html](https://kotlinlang.org/docs/home.html) \[Accessed 2 May 2025].
//
//6. Android Developers. (2023). *Saving Data with SharedPreferences*. \[online] Available at: [https://developer.android.com/training/data-storage/shared-preferences](https://developer.android.com/training/data-storage/shared-preferences) \[Accessed 2 May 2025].
//
//7. Android Developers. (2023). *ViewModel Overview*. \[online] Available at: [https://developer.android.com/topic/libraries/architecture/viewmodel](https://developer.android.com/topic/libraries/architecture/viewmodel) \[Accessed 2 May 2025].
//
//8. Android Developers. (2023). *Activities*. \[online] Available at: [https://developer.android.com/guide/components/activities](https://developer.android.com/guide/components/activities) \[Accessed 2 May 2025].
//
//9. Android Developers. (2023). *Room Database Migration*. \[online] Available at: [https://developer.android.com/training/data-storage/room/migrating](https://developer.android.com/training/data-storage/room/migrating) \[Accessed 2 May 2025].
//
//10. Google. (2023). *Material Design*. \[online] Available at: [https://material.io/design](https://material.io/design) \[Accessed 2 May 2025].

