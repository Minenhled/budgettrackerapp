package vcmsa.projects.budgettrackerapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import vcmsa.projects.budgettrackerapp.ui.theme.BudgetTrackerAppTheme
import vcmsa.projects.budgettrackerapp.ui.theme.ui.screen.BudgetTrackerApp
import vcmsa.projects.budgettrackerapp.viewmodel.AuthViewModel

class MainActivity : ComponentActivity() {
    private val authViewModel by viewModels<AuthViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BudgetTrackerAppTheme {
                BudgetTrackerApp(authViewModel)
            }
        }
    }
}


