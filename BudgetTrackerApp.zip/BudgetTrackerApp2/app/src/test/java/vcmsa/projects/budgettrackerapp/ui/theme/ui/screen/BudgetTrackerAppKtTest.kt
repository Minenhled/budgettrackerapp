package vcmsa.projects.budgettrackerapp.ui.theme.ui.screen

import org.junit.jupiter.api.Assertions.*

class BudgetTrackerAppKtTest