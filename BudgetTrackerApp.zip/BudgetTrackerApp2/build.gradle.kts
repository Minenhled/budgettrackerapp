// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
buildscript {
    // The `buildscript` block is usually deprecated in newer Gradle setups unless you're stuck with older tools.
    // If you're using the new `plugins {}` DSL (as you are), you should remove this unless needed.
    dependencies {
        // Remove this if you're not explicitly applying the google-services plugin via legacy method
        classpath("com.google.gms:google-services:4.3.15")
    }
}